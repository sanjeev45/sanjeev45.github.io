"""Icon links module for social media links."""

data = {
    "discord": "https://discord.cdrm-project.com/",
    "telegram": "https://telegram.cdrm-project.com/",
    "gitea": "https://cdm-project.com/tpd94/cdrm-project",
}
