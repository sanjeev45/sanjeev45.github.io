
# CDRM-Project

 ![forthebadge](https://forthebadge.com/images/badges/uses-html.svg) ![forthebadge](https://forthebadge.com/images/badges/uses-css.svg) ![forthebadge](https://forthebadge.com/images/badges/uses-javascript.svg) ![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)  
  
## Prerequisites (from source only)
  
- [Python](https://www.python.org/downloads/) version 3.12+ with PIP installed  

  Python 3.13 was used at the time of writing

- [Node.js](https://nodejs.org/en/download/) v20+

## Installation (Automatic) - Recommended

- Extract contents of CDRM-Project into a new folder
- Open a terminal and change directory into the new folder
- Run `python build.py && python main.py`
- Follow the on-screen prompts

## Installation (From binary)

- Download the latest release from the [releases](https://cdm-project.com/tpd94/CDRM-Project/releases) page and run the `.exe`

## Installation  (Manual)

- Open your terminal and navigate to where you'd like to store the application
- Clone the project with `git clone https://cdm-project.com/tpd94/CDRM-Project.git`
- Navigate to the `CDRM-Project` folder
- Create a new python virtual environment using `python -m venv venv`
- Activate the virtual environment

  - Windows:
  
  ```bash
  .\venv\Scripts\activate
  ```

  - Linux:
  
  ```bash
  source venv/bin/activate
  ```

  Verify that the virtual environment is activated by seeing the `(venv)` prefix in your terminal

- Install python dependencies `pip install -r requirements.txt`
- (Optional) Create the folder structure `/configs/CDMs/WV` and place your .WVD file into `/configs/CDMs/WV`
- (Optional) Create the folder structure `/config/CDMs/PR` and place your .PRD file into `/configs/CDMs/PR`
- Build the frontend with `python build.py`
- And finally, run the application with `python main.py`
