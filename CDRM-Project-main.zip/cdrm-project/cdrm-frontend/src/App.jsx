import { Route, Routes } from "react-router-dom";
import Account from "./components/Pages/Account";
import API from "./components/Pages/API";
import Cache from "./components/Pages/Cache";
import Home from "./components/Pages/HomePage";
import TestPlayer from "./components/Pages/TestPlayer";

function App() {
    return (
        <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/cache" element={<Cache />} />
            <Route path="/api" element={<API />} />
            <Route path="/testplayer" element={<TestPlayer />} />
            <Route path="/account" element={<Account />} />
        </Routes>
    );
}

export default App;
