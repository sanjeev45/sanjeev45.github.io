"""Module to run the prechecks."""

import os
import subprocess

from custom_functions.prechecks.folder_checks import folder_checks
from custom_functions.prechecks.config_file_checks import check_for_config_file
from custom_functions.prechecks.database_checks import check_for_sql_database
from custom_functions.prechecks.cdm_checks import check_for_cdms


def check_frontend_built():
    """Check if the frontend is built; if not, run build.py."""
    frontend_dist = os.path.join(os.getcwd(), "frontend-dist")
    frontend_dist = os.path.abspath(frontend_dist)
    if not os.path.exists(frontend_dist) or not os.listdir(frontend_dist):
        print("Frontend has not been built. Running build.py...")
        subprocess.run(["python", "build.py"], check=True)
    else:
        print("Frontend build found.")


def run_precheck():
    """Run the prechecks."""
    check_frontend_built()
    folder_checks()
    check_for_config_file()
    check_for_cdms()
    check_for_sql_database()
