"""Module to check for the folders."""

import os


def check_for_config_folder():
    """Check for the config folder."""
    if os.path.isdir(os.path.join(os.getcwd(), "configs")):
        return
    os.mkdir(os.path.join(os.getcwd(), "configs"))
    return


def check_for_database_folder():
    """Check for the database folder."""
    if os.path.isdir(os.path.join(os.getcwd(), "databases")):
        return
    os.mkdir(os.path.join(os.getcwd(), "databases"))
    os.mkdir(os.path.join(os.getcwd(), "databases", "sql"))
    return


def check_for_cdm_folder():
    """Check for the CDM folder."""
    if os.path.isdir(os.path.join(os.getcwd(), "configs", "CDMs")):
        return
    os.mkdir(os.path.join(os.getcwd(), "configs", "CDMs"))
    return


def check_for_wv_cdm_folder():
    """Check for the Widevine CDM folder."""
    if os.path.isdir(os.path.join(os.getcwd(), "configs", "CDMs", "WV")):
        return
    os.mkdir(os.path.join(os.getcwd(), "configs", "CDMs", "WV"))
    return


def check_for_cdm_pr_folder():
    """Check for the PlayReady CDM folder."""
    if os.path.isdir(os.path.join(os.getcwd(), "configs", "CDMs", "PR")):
        return
    os.mkdir(os.path.join(os.getcwd(), "configs", "CDMs", "PR"))
    return


def folder_checks():
    """Check for the folders."""
    check_for_config_folder()
    check_for_database_folder()
    check_for_cdm_folder()
    check_for_wv_cdm_folder()
    check_for_cdm_pr_folder()
